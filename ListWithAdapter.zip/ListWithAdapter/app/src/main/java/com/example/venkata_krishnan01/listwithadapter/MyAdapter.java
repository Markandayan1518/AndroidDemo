package com.example.venkata_krishnan01.listwithadapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Venkata_Krishnan01 on 4/11/2016.
 */
public class MyAdapter extends ArrayAdapter {
    private Map<String,Integer> myMap=new LinkedHashMap<>();
    private List<String> mylist;
    private Context context;
    MyAdapter(Context context, int textViewResourceId,
              List<String> objects){

        super(context, textViewResourceId, objects);
        this.context=context;
        mylist=objects;

        for (int i = 0; i < objects.size(); ++i) {
            myMap.put(objects.get(i), textViewResourceId);
        }
    }
    @Override

    public int getCount() {
        return mylist.size();
    }

    @Override
    public Object getItem(int i) {
       return mylist.get(i);

    }

    @Override
    public long getItemId(int i) {
        return myMap.get(mylist.get(i));
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {

            LayoutInflater inflater = (LayoutInflater) LayoutInflater
                    .from(context);
            view = inflater.inflate(R.layout.listitemlayout, viewGroup, false);

        }


        TextView tv=(TextView)view.findViewById(R.id.textView);
        tv.setText(mylist.get(i));
        return view;
    }

    public void delete(String tbd) {

        myMap.remove(tbd);
        mylist.remove(tbd);
        notifyDataSetChanged();
    }
    public void deleteWithIndex(int tbd){
        String s=mylist.get(tbd);
        mylist.remove(tbd);
        myMap.remove(s);
        notifyDataSetChanged();;

    }
}
