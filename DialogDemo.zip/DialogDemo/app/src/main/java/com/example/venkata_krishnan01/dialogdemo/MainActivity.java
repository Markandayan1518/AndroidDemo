package com.example.venkata_krishnan01.dialogdemo;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button b1,b2,b3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.confirm);
        b2=(Button)findViewById(R.id.date);
        b3=(Button)findViewById(R.id.time);

        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==b1.getId()){
            new AlertDialog.Builder(this).setTitle("Dialog").
                    setPositiveButton("OK", null).
                    setNegativeButton("Cancel",null).
                    setNeutralButton("Do not", null).show();

        }
        else if(v.getId()==b2.getId()){
            DatePickerDialog d=new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    b2.setText(""+dayOfMonth+"-"+monthOfYear+"-"+year);
                }
            },2016,04,20);

            TimePickerDialog tpd=new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                }
            },10,00,true);
        }
    }
}
