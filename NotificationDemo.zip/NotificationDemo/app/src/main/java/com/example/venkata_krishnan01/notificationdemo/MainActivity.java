package com.example.venkata_krishnan01.notificationdemo;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.Context;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        NotificationCompat.Builder n= new NotificationCompat.Builder(this);
        n.setContentTitle("Notify");
        n.setContentText("Something");
        n.setSmallIcon(R.mipmap.ic_launcher);

        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            nm.notify(1,n.build());
    }
}
