package com.example.venkata_krishnan01.bpdemoasync;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {
    private FibCalc myFibCalc = null;
    public ProgressBar pb=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pb=(ProgressBar)findViewById(R.id.progressBar1);
        pb.setVisibility(View.INVISIBLE);
        // Get a handle to btnCalc and set the click listener that creates a FibCalc object (AsyncTask) and calls execute() to do background processing
        Button btnCalc = (Button)findViewById( R.id.btnCalc );
        btnCalc.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View btnCalc) {
                // Get a handle to the input EditText, read its value - n, convert to an integer and calculate the nth Fibonacci number in the background using FibCalc object (of AsyncTask type)
                EditText editN 	= (EditText) MainActivity.this.findViewById( R.id.editN );
                myFibCalc 		= new FibCalc();
                myFibCalc.execute( Integer.parseInt( editN.getText().toString() ) );
            }
        });

        // Get a handle to btnCancel and set the click listener that creates a FibCalc object (AsyncTask) and calls execute() to do background processing
        Button btnCancel = (Button)findViewById( R.id.btnCancel );
        btnCancel.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View btnCancel) {
                pb.setVisibility(View.INVISIBLE);
                myFibCalc.cancel( true );
            }
        });
    }

    private class FibCalc extends AsyncTask<Integer, Integer, Long>
    {

        // Method that returns the nth Fibonacci number - it is executed in the background thread as it is called within doInBackground()
        private Long fib( Integer n )
        {
/*			if( isCancelled() )
				return 0L;
*/
            if( n == 1 || n == 2 )
                return 1L;

            return fib( n - 1 ) + fib( n - 2 );
        }

        // This method is executed in the background thread
        @Override
        protected Long doInBackground(Integer... n) {

            return fib( n[0] );

        }
        @Override
        protected void onPreExecute() {
            // TODO Auto-generated method stub
            //super.onPreExecute();
            pb.setVisibility(View.VISIBLE);
        }

        // This method is executed on the UI thread
        @Override
        protected void onPostExecute(Long result)
        {
            //super.onPostExecute( result );

            // Get handle to the editResult and publish the result there

            EditText editResult = (EditText)findViewById( R.id.editResult );
            editResult.setText( result.toString() );
            pb.setVisibility(View.INVISIBLE);
        }


//	@Override
//		protected void onCancelled(Long result)
//		{
//			// Get handle to the editResult and publish the result there
//			EditText editResult = (EditText)findViewById( R.id.editResult );
//			editResult.setText( "Cancelled" );
//		}
	}
}