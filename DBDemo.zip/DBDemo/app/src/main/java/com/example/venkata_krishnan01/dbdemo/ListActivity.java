package com.example.venkata_krishnan01.dbdemo;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {
    ListView lv=null;
    ArrayList<String> ars=new ArrayList<>();
    ArrayList<Integer> ari=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        fetchFromDb();
        lv=(ListView)findViewById(R.id.listView);

        lv.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, ars));
       registerForContextMenu(lv);

    }
    public void fetchFromDb(){
        MyDBAdapter adp=new MyDBAdapter(this);
        adp.open();
        Cursor c=adp.getAllEntries();
        c.moveToFirst();
        ars.clear();
        ari.clear();
        for(int i=0;i<c.getCount();i++){
            Toast.makeText(this,"count"+c.getCount(),Toast.LENGTH_SHORT).show();

//            Toast.makeText(this,"elem"+c.getString(0),Toast.LENGTH_SHORT).show();
//            Toast.makeText(this,"elem"+c.getColumnIndex("langName"),Toast.LENGTH_SHORT).show();
//            Toast.makeText(this,"elem"+c.getString(c.getColumnIndex("langName")),Toast.LENGTH_SHORT).show();
            ars.add(i, c.getString(1));
            ari.add(i,c.getInt(0));
            c.moveToNext();

        }
        c.close();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        menu.add("delete");


    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        if(item.getTitle().equals("delete")){
            MyDBAdapter dba=new MyDBAdapter(this);
            dba.open();
            dba.removeEntry(ari.get(info.position));
            dba.close();
        }
        fetchFromDb();
        ((BaseAdapter)   lv.getAdapter()).notifyDataSetChanged();
        return false;
    }
}
