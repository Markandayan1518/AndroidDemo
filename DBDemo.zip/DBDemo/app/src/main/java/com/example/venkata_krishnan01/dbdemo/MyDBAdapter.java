package com.example.venkata_krishnan01.dbdemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Venkata_Krishnan01 on 4/13/2016.
 */
public class MyDBAdapter {
    private static final String DB_NAME = "MY_DATABASE";
    private static final String DB_TABLE = "language";
    private static final int DB_VERSION = 1;

    private static final String KEY_ID = "_id";

    private static final String COLMN_NAME = "langName";
    private static final int COLMN_INDEX = 1;


    private static final String DB_CREATE = "create table " + DB_TABLE + " (" + KEY_ID + " integer primary key " +
            "autoincrement , " + COLMN_NAME + " text not null);";


    private SQLiteDatabase database;
    private final Context context;
    private MyDBHelper helper;

    public MyDBAdapter(Context context) {

        this.context = context;
        helper = new MyDBHelper(context, DB_NAME, null, DB_VERSION);

    }

    public MyDBAdapter open() {

        database = helper.getWritableDatabase();
        return this;
    }

    public void close() {
        database.close();
    }

    public long insertEntry(String langName) {
        Log.d("inserting",langName);
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLMN_NAME, langName);
        return database.insert(DB_TABLE, null, contentValues);
    }

    public boolean removeEntry(long rowIndex) {
        return database.delete(DB_TABLE, KEY_ID + " = " + rowIndex, null) > 0;
    }

    public Cursor getAllEntries() {

        return database.query(DB_TABLE, new String[]{KEY_ID, COLMN_NAME}, null, null, null, null, null);

    }

    public int updateEntry(long rowIndex, String langName) {

        ContentValues updateValues = new ContentValues();
        updateValues.put(COLMN_NAME, langName);
        return database.update(DB_TABLE, updateValues, KEY_ID + " = " + rowIndex, null);
    }

    private static class MyDBHelper extends SQLiteOpenHelper {
        public MyDBHelper(Context context, String name, SQLiteDatabase.CursorFactory cursorFactory, int version) {
            super(context, name, cursorFactory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            // TODO Auto-generated method stub
            db.execSQL(DB_CREATE);

            List<String> languages = new ArrayList<String>();
            languages.add("C");
            languages.add("C++");
            languages.add("Java");
            languages.add("Perl");

            for (String string : languages) {
                ContentValues contentValues = new ContentValues();
                contentValues.put(COLMN_NAME, string);

                db.insert(DB_TABLE, null, contentValues);
            }
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            // TODO Auto-generated method stub
            Log.w("Updation", "Data base version is being updated");
            db.execSQL("DROP TABLE IF EXISTS " + DB_TABLE);
            onCreate(db);
        }


    }
}