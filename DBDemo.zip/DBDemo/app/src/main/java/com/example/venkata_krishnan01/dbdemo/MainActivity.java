package com.example.venkata_krishnan01.dbdemo;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
Button b=null;
    Button b2=null;
    EditText ed=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b=(Button )findViewById(R.id.button);
        b2=(Button)findViewById(R.id.button2);
        ed=(EditText)findViewById(R.id.editText);
    b.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        MyDBAdapter adapter = new MyDBAdapter(MainActivity.this);
        adapter.open();
        Toast.makeText(MainActivity.this,"adding "+ed.getText().toString(),Toast.LENGTH_SHORT).show();
        adapter.insertEntry(ed.getText().toString());
        adapter.close();

    }
});
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(MainActivity.this,ListActivity.class);
                startActivity(i);
            }


        });

//        myAsync my=new myAsync();
//        my.execute(ed.getText().toString());
    }
}
//class myAsync extends AsyncTask<String,Integer,String>{
//
//    @Override
//    protected String doInBackground(String... params) {
//        StringBuilder stringBuilder = new StringBuilder();
//        try {
//            URL url = new URL("http://10.0.2.2:8080/MySerlvet/Servlet");
//            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

//            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
//
//            String line;
//            while ((line = bufferedReader.readLine()) != null) {
//                stringBuilder.append(line).append("\n");
//            }
//            bufferedReader.close();
//        }
//        catch(Exception e){
//
//        }
//
//            return stringBuilder.toString();
//
//
//    }

