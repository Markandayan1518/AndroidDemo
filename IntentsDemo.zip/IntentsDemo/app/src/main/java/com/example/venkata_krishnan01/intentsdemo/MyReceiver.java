package com.example.venkata_krishnan01.intentsdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.widget.Toast;

/**
 * Created by Venkata_Krishnan01 on 4/12/2016.
 */
public class MyReceiver extends BroadcastReceiver {
    Context con=null;
    @Override

    public void onReceive(Context context, Intent intent) {
        con = context;
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            String incomingNo;
            String smsMessage;
            Object[] pdus = (Object[]) bundle.get("pdus");
            SmsMessage[] msgs = new SmsMessage[pdus.length];
            for (int i = 0; i < pdus.length; i++) {
                msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                incomingNo = msgs[i].getOriginatingAddress();
                smsMessage = msgs[i].getMessageBody();
                DisplayToast("Message from " + incomingNo + "\n" + "SMS body: " + smsMessage);
            }
        }
    }
        private void DisplayToast(String S){

            Toast.makeText(con, S, Toast.LENGTH_LONG).show();
        }
    }
