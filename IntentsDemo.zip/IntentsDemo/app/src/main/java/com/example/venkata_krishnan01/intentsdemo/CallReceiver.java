package com.example.venkata_krishnan01.intentsdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.widget.Toast;

/**
 * Created by Venkata_Krishnan01 on 4/12/2016.
 */
public class CallReceiver extends BroadcastReceiver {
   Context con = null;

    @Override
    public void onReceive(Context context, Intent intent) {
        con=context;
        DisplayToast(intent.getAction());
        if(intent.getAction().equals("android.intent.action.PHONE_STATE")){
			processcall(intent);
            DisplayToast("Phone State Changed");
        }
    }

    private void processcall(Intent intent){
        String incomingNo = intent.getStringExtra(	TelephonyManager.EXTRA_INCOMING_NUMBER);
        String callState = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        if(callState.equals(TelephonyManager.EXTRA_STATE_RINGING)){
            DisplayToast("Incoming call from "+incomingNo);
        }else if(callState.equals(TelephonyManager.EXTRA_STATE_OFFHOOK)){
            DisplayToast("Incoming call answered");
        }else if(callState.equals(TelephonyManager.EXTRA_STATE_IDLE)){
            DisplayToast("Incoming call disconnected");
        }
    }
    private void DisplayToast(String S){
        Toast.makeText(con,S , Toast.LENGTH_LONG).show();
    }
}


